PRODNEXA AGENCY — WEBSITE PREVIEW

Open index.html in your browser to view the website. All eight pages are navigable via the header and footer.

Pages: Home, About, Services, AI Commercials, Our Approach, Industries, Insights, Contact.

Brand palette:
- Midnight navy: #1e2b41 (from provided logo)
- White: #ffffff
- Single additional accent: muted gold #c6aa78
- Neutral grey tones are used only for supporting text/background treatments.

Included: optimized copies of all six uploaded photographs, cropped transparent-background version of supplied logo, responsive mobile navigation, reveal animations, original site copy, editable static files.

IMPORTANT BEFORE GOING LIVE:
- The contact form is a working mailto preview: it opens the visitor's email application addressed to kgodswill856@gmail.com. It DOES NOT submit form data to a server; connect a secure backend/form provider for reliable submissions.
- The photographs you supplied are used as brand imagery. The site does not claim that the depicted people are employees.
- No unverified testimonials, company metrics, case studies, or performance guarantees have been published.
- Google Fonts requires internet. Fallback system fonts are provided.

Deploy: Upload the contents of this folder to Cloudflare Pages or Netlify. For Cloudflare Pages direct upload, upload the ZIP or files as your deployment flow requires.
