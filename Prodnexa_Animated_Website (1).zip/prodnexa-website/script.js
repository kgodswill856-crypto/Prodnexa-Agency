(() => {
  const menu = document.querySelector('.menu-toggle');
  const mobile = document.querySelector('.mobile-nav');
  if (menu && mobile) {
    menu.addEventListener('click', () => {
      const open = mobile.classList.toggle('open');
      menu.setAttribute('aria-expanded', String(open));
      menu.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    });
    mobile.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      mobile.classList.remove('open'); menu.setAttribute('aria-expanded', 'false');
    }));
  }
  const year = document.getElementById('year');
  if(year) year.textContent = new Date().getFullYear();
  if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const obs = new IntersectionObserver((entries) => {
      for(const e of entries) if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}
    },{threshold:0.08});
    document.querySelectorAll('.reveal').forEach((el,i)=>{el.style.setProperty('--pd-delay',(i%4)*90+'ms');obs.observe(el)});
  } else document.querySelectorAll('.reveal').forEach(el=>el.classList.add('visible'));
  const form = document.getElementById('contact-form');
  if(form){form.addEventListener('submit',event=>{
    event.preventDefault();
    if(!form.reportValidity())return;
    const data=new FormData(form);
    const get=k=>String(data.get(k)||'').trim();
    const subject=`Prodnexa Agency enquiry — ${get('company')}`;
    const body=`Name: ${get('name')}\nEmail: ${get('email')}\nBrand: ${get('company')}\nWebsite/Social: ${get('website')}\nService: ${get('service')}\n\nGoals:\n${get('message')}`;
    const mailto='mailto:kgodswill856@gmail.com?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body);
    const status=form.querySelector('.form-feedback');
    status.textContent='Your email application should open with the completed enquiry. Please send the email there to finish.';
    window.location.href=mailto;
  });}
})();
